package uk.ac.le.co2103.hw4;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;

import java.util.ArrayList;
import java.util.List;

public class ProductListAdapter extends ListAdapter<Product, ProductViewHolder> {
    private OnItemListener mOnItemListener;
    private Product current;



    protected ProductListAdapter(@NonNull DiffUtil.ItemCallback<Product> diffCallback, OnItemListener mOnItemListener) {
        super(diffCallback);
        this.mOnItemListener = mOnItemListener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return ProductViewHolder.create(parent, mOnItemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        current = getItem(position);
        holder.bind(current.getName());
        this.setProduct(current);
    }


    public String getProductName() {
        return current.name;
    }

    public String getProductQty(){
        return current.quantity;
    }


    public void setProduct(Product current) {
        this.current = current;
    }

    public Product getProduct() {
        return current;
    }

    static class ItemDiff extends DiffUtil.ItemCallback<Product>{

        @Override
        public boolean areItemsTheSame(@NonNull Product oldItem, @NonNull Product newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Product oldItem, @NonNull Product newItem) {
            return oldItem.getName().equals(newItem.getName());
        }
    }

    public interface OnItemListener {
        void onItemClick(int position);
    }




}
