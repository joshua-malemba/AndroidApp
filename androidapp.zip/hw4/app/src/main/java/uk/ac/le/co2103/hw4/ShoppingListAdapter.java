package uk.ac.le.co2103.hw4;

import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

public class ShoppingListAdapter extends ListAdapter<ShoppingList, ShoppingListViewHolder> {
    private OnItemListener mOnItemListener;
    private OnLongClickItemListener longClickItemListener;
    private ShoppingList current;
    private Button addimage_Button;

    protected ShoppingListAdapter(@NonNull DiffUtil.ItemCallback<ShoppingList> diffCallback, OnItemListener mOnItemListener, OnLongClickItemListener longClickItemListener) {
        super(diffCallback);
        this.mOnItemListener = mOnItemListener;
        this.longClickItemListener = longClickItemListener;
    }

    @NonNull
    @Override
    public ShoppingListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return ShoppingListViewHolder.create(parent, viewType, mOnItemListener, longClickItemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ShoppingListViewHolder holder, int position) {
        current = getItem(position);
        holder.bind(current.getName());
        setImageButton(holder.getAddImage_button());
    }
    public ShoppingList getShoppingList() {
        return current;
    }

    public void setShoppingList(ShoppingList current) {
        this.current = current;
    }

    public void setImageButton(Button button){
        this.addimage_Button = button;
    }
    public Button getImageButton(){
        return addimage_Button;
    }

    static class ItemDiff extends DiffUtil.ItemCallback<ShoppingList> {

        @Override
        public boolean areItemsTheSame(@NonNull ShoppingList oldItem, @NonNull ShoppingList newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull ShoppingList oldItem, @NonNull ShoppingList newItem) {
            return oldItem.getName().equals(newItem.getName());
        }
    }

    public interface OnItemListener {
        void onItemClick(int position);
    }
    
    public interface OnLongClickItemListener{
        void longOnItemClick(int position);
    }
}
