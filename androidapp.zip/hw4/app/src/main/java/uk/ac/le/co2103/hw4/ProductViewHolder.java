package uk.ac.le.co2103.hw4;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import uk.ac.le.co2103.hw4.ProductListAdapter;

public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    private final TextView productTextView;
    private static ProductListAdapter.OnItemListener mOnItemListener;
    private static String TAG = ProductViewHolder.class.getSimpleName();
    private Product current;

    public ProductViewHolder(@NonNull View productView, ProductListAdapter.OnItemListener mOnItemListener) {
        super(productView);
        productTextView = productView.findViewById(R.id.textView);
        this.mOnItemListener = mOnItemListener;
        productView.setOnClickListener(this);
    }

    public void bind(String text){
        productTextView.setText(text);
    }

    static ProductViewHolder create(ViewGroup parent, ProductListAdapter.OnItemListener mOnItemListener){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_shopping_list, parent, false);
        return new ProductViewHolder(view, mOnItemListener);
    }

    @Override
    public void onClick(View v) {
        Log.d(TAG, "product clicked...");
        mOnItemListener.onItemClick(getAdapterPosition());
    }

}
