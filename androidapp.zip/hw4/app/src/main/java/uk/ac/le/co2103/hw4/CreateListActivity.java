package uk.ac.le.co2103.hw4;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.*;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.net.URI;

@SuppressWarnings("ALL")
public class CreateListActivity extends AppCompatActivity {
    private static final String TAG = CreateListActivity.class.getSimpleName();
    public static final String EXTRA_REPLY = "uk.edu.le.co2103.hw4.REPLY";
    public static final String IMAGE = "uk.edu.le.co2103.co2103.hw4.IMAGE";
    public static final String NAME = "uk.edu.le.co2103.co2103.hw4.NAME";



    private static Uri imageData;


    public static int MAIN_ACTIVITY_REQUEST_CODE = 1;
    private EditText editTextItem;
    private static final int IMAGE_PICK_CODE = 1000;
    private static final int PERMISSION_CODE = 1000;
    private static ImageView image;
    private Bitmap bitImage;

    public static Uri getImageData() {
        return imageData;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_list);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        editTextItem = findViewById(R.id.editTextTextPersonName);

        Log.d(TAG, "Setting up add image and image button");
        image = (ImageView) findViewById(R.id.image);
        Button addImage = findViewById(R.id.button_image);
        addImage.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    // if permission is denied....
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                            == PackageManager.PERMISSION_DENIED){
                        // request for permission
                        String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        requestPermissions(permissions, PERMISSION_CODE);
                    }
                    else{
                        attachImage();

                    }

                }
            }
        });



        Button create = findViewById(R.id.button_first);
        create.setOnClickListener(view -> {
        Intent replyIntent = new Intent();
            Bundle extras = new Bundle();
            if (TextUtils.isEmpty(editTextItem.getText())) {
            Log.i(TAG, "Empty text field could be controlled in UI(Save button is disabled)");
            setResult(RESULT_CANCELED, replyIntent);
            }
            else {
        Log.i(TAG, "Adding shopping list to set");
        String item = editTextItem.getText().toString();
        ImageView theChosenImage = image;

        replyIntent.putExtra(EXTRA_REPLY, item);
        replyIntent.putExtra(IMAGE, bitImage);

        // find a way to pass image via here
        setResult(RESULT_OK, replyIntent);
            }
            finish();
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if (requestCode == IMAGE_PICK_CODE && resultCode == RESULT_OK){
            image.setImageURI(data.getData());
            image.setDrawingCacheEnabled(true);
            bitImage=image.getDrawingCache();
        }
    }

    private void attachImage() {
        Intent attachIntent = new Intent(Intent.ACTION_PICK);
        attachIntent.setType("image/*");
        startActivityForResult(attachIntent, IMAGE_PICK_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    /// permission grant successful
                    attachImage();
                }
                else{
                    /// denied
                    Toast.makeText(this, "Permission was denied !", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}

