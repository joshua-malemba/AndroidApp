
package uk.ac.le.co2103.hw4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.net.CookieHandler;
import java.util.*;

import uk.ac.le.co2103.hw4.R;
import uk.ac.le.co2103.hw4.ShoppingListViewModel;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity implements ShoppingListAdapter.OnItemListener, ShoppingListAdapter.OnLongClickItemListener{

    private static String TAG = MainActivity.class.getSimpleName();
    public static int CREATE_LIST_ACTIVITY_REQUEST_CODE = 1;
    private ShoppingListViewModel shoppingListViewModel;
    private String[] dialogOptions = {"Delete"};
    private ShoppingListAdapter adapter;
    private ImageView image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d(TAG, "onCreate()");

        setContentView(R.layout.activity_main);

        Log.d(TAG, "Creating recyclerView");
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        adapter = new ShoppingListAdapter(new ShoppingListAdapter.ItemDiff(), this, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        Log.d(TAG, "Adding items to adapter");
        shoppingListViewModel = new ViewModelProvider(this).get(ShoppingListViewModel.class);
        shoppingListViewModel.getAllShoppingLists().observe(this, items -> {
                    adapter.submitList(items);
                });


        Log.d(TAG, "Setting up floating action");
        final FloatingActionButton button = findViewById(R.id.fab);
        button.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, CreateListActivity.class);
            startActivityForResult(intent, CREATE_LIST_ACTIVITY_REQUEST_CODE);
        });
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CREATE_LIST_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK){
            ShoppingList shoppingList = new ShoppingList(data.getStringExtra(CreateListActivity.EXTRA_REPLY));

   //         image = (ImageView) findViewById(R.id.image);
    //        image.setImageBitmap(bitmap);

            // do we need to conisder position of image ?
        shoppingListViewModel.insert(shoppingList);
        }
        else{
            Toast.makeText(getApplicationContext(),
                    R.string.empty_not_saved,
                    Toast.LENGTH_LONG).show();
             }
        }


    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(this, ShoppingListActivity.class);
        startActivity(intent);
    }

    /// on long item click initiate dialog option to delete shopping list and all it's products

    @Override
    public void longOnItemClick(int position) {
        Log.d(TAG, "Creating alertDialog builder....");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose An Action")
                .setItems(R.array.dialog_delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if("Delete".equals(dialogOptions[which])){
                            /// delete shopping list
                            ShoppingList thatShoppingList = adapter.getShoppingList();
                            shoppingListViewModel.delete(thatShoppingList);
                        }
                    }
                });
        builder.create();
        builder.show();
    }
}