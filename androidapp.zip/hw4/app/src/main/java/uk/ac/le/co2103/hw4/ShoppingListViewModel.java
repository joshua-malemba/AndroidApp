package uk.ac.le.co2103.hw4;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ShoppingListViewModel extends AndroidViewModel {
    private ShoppingRepository repo;
    private LiveData<List<ShoppingList>> allShoppingLists;

    public ShoppingListViewModel(Application application) {
        super(application);
        repo = new ShoppingRepository(application);
        allShoppingLists = repo.getAllShoppingLists();
    }

    LiveData<List<ShoppingList>> getAllShoppingLists(){
        return allShoppingLists;
    }

    public void insert(ShoppingList shoppingList){
        repo.insert(shoppingList);
    }

    public void delete(ShoppingList shoppingList){
        repo.delete(shoppingList);
    }
}
