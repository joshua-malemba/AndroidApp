package uk.ac.le.co2103.hw4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.*;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ShoppingListActivity extends AppCompatActivity implements ProductListAdapter.OnItemListener{

    private static String TAG = ShoppingListActivity.class.getSimpleName();
    public static int ADD_PRODUCT_ACTIVITY_REQUEST_CODE = 1;
    public static int UPDATE_PRODUCT_ACTIVITY_REQUEST_CODE = 1;

    public static final String NAME = "uk.edu.le.co2103.co2103.hw4.NAME";
    public static final String QTY = "uk.edu.le.co2103.co2103.hw4.QTY";


    private ProductViewModel productViewModel;
    private ProductViewHolder productViewHolder;
    private String[] dialogOptions = {"Edit", "Delete"};
    private String[] spinnerOptions = {"Unit", "Kg", "Liter"};

    private ProductListAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);

        Log.d(TAG, "Creating recyclerView");
        RecyclerView recyclerView = findViewById(R.id.recyclerview1);
        adapter = new ProductListAdapter(new ProductListAdapter.ItemDiff(), (ProductListAdapter.OnItemListener) this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Log.d(TAG, "Adding items to adapter");
        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        productViewModel.getAllProducts().observe(this, items -> {
            adapter.submitList(items);
        });





        Log.d(TAG, "Setting up floating action");
        final FloatingActionButton button = findViewById(R.id.fab1);
        button.setOnClickListener(view -> {
            Intent intent = new Intent(ShoppingListActivity.this, AddProductActivity.class);
            startActivityForResult(intent, ADD_PRODUCT_ACTIVITY_REQUEST_CODE);
        });
    }



    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == ADD_PRODUCT_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK){

            Product product = new Product(data.getStringExtra(AddProductActivity.EXTRA_REPLY));
            //// check if product exists in productViewModel
            List<Product> products =  productViewModel.getAllProducts().getValue();
            for (Product p : products){
                if (p.getName().equals(product.getName())){
                    /// if the product already exists, return toast message
                    Toast.makeText(getApplicationContext(),
                            "Product already exists",
                            Toast.LENGTH_LONG).show();
                }else{
                    productViewModel.insert(product);
                    break;
                }

            }
        }
        else{
            Toast.makeText(getApplicationContext(),
                    R.string.empty_not_saved,
                    Toast.LENGTH_LONG).show();
        }
    }
    //// on click of a product, create a dialog with options "Edit" and "Delete".

    // The 'which' argument contains the index position
    // of the selected option

    @Override
    public void onItemClick(int position) {

        Log.d(TAG, "Creating alertDialog builder....");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose An Action")
                .setItems(R.array.dialog, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if("Edit".equals(dialogOptions[which])){
                            //// navigate to UpdateProductActivity
                            Intent intent = new Intent(ShoppingListActivity.this, UpdateProductActivity.class);
                            Bundle extras = new Bundle();

                            /// access the fields of the current product
                            Product thatProduct = adapter.getProduct();
                            String theProductName = adapter.getProductName();
                            String theProductQty = adapter.getProductQty();
                            
                            /// pass product details to UpdateProductActivity

                            extras.putString(NAME, theProductName);
                            extras.putString(QTY, theProductQty);

                            intent.putExtras(extras);
                            startActivityForResult(intent, UPDATE_PRODUCT_ACTIVITY_REQUEST_CODE);
                            // delete product with older details

                            productViewModel.deleteProduct(thatProduct);

                        }
                        else if("Delete".equals(dialogOptions[which])){
                            // delete that product
                            Product thatProduct = adapter.getProduct();
                            Log.d(TAG, "Deleting product....");
                            productViewModel.deleteProduct(thatProduct);
                        }
                    }
                });
         builder.create();
         builder.show();
    }
}