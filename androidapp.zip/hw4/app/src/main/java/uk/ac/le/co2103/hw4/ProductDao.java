package uk.ac.le.co2103.hw4;
import androidx.room.*;
import androidx.lifecycle.*;
import uk.ac.le.co2103.hw4.Product;
import java.util.*;

@Dao
public interface ProductDao {

    @Insert
    void insert(Product product);

    @Query("DELETE FROM products")
    void deleteAll();

    @Query("SELECT * FROM products ORDER BY name ASC")
    LiveData<List<Product>> getShoppingLists();

    @Delete
    void delete(Product product);
}
