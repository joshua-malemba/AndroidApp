package uk.ac.le.co2103.hw4;
import android.net.Uri;
import android.widget.ImageView;

import androidx.room.*;
import androidx.annotation.*;

import uk.ac.le.co2103.hw4.Product;
import java.util.List;
@Entity(tableName = "shopping_list")

public class ShoppingList {

    @PrimaryKey(autoGenerate = true)
    public int listid;

    public int productOwnerId;

    @ColumnInfo(name = "name")
    public String name;


    public ShoppingList(@NonNull String name){
        this.name = name;
    }


    public int getId() {
        return listid;
    }

    public void setId(int id) {
        this.listid = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
