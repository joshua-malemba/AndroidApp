package uk.ac.le.co2103.hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

@SuppressWarnings("ALL")
public class AddProductActivity extends AppCompatActivity {

    private static final String TAG = AddProductActivity.class.getSimpleName();
    public static final String EXTRA_REPLY = "uk.edu.le.co2103.hw4.REPLY";
    public static int ADD_PRODUCT_ACTIVITY_REQUEST_CODE = 1;


    private EditText editTextItem;
    private EditText editTextQty;
    private Spinner spinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        editTextItem = findViewById(R.id.editTextName);
        editTextQty = findViewById(R.id.editTextQuantity);

        spinner = findViewById(R.id.spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.labels_unit, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);

        Button add = findViewById(R.id.add_button);

        add.setOnClickListener(view -> {
            Intent replyIntent = new Intent();
            if (TextUtils.isEmpty(editTextItem.getText())) {
                Log.i(TAG, "Empty text field could be controlled in UI(Save button is disabled)");
                setResult(RESULT_CANCELED, replyIntent);
            }

            else {
                Log.i(TAG, "Adding new product to shopping list");
                String item = editTextItem.getText().toString();
                replyIntent.putExtra(EXTRA_REPLY, item);
                setResult(RESULT_OK, replyIntent);
            }
            finish();
        });




    }
}