package uk.ac.le.co2103.hw4;

import uk.ac.le.co2103.hw4.ShoppingCartDB;
import androidx.room.*;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.annotation.*;
import java.util.*;
import android.content.*;

import java.util.concurrent.*;
@Database(entities = {Product.class, ShoppingList.class}, version = 1, exportSchema = false)
public abstract class ShoppingCartDB extends RoomDatabase {

    public abstract ProductDao productDao();
    public abstract ShoppingListDao shoppingListDao();


    private static volatile ShoppingCartDB INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    static ShoppingCartDB getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized(ShoppingCartDB.class){
                if (INSTANCE == null){
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), ShoppingCartDB.class,
                            "shoppingcart_db").addCallback(sRoomDatabaseCallback).build();
                }
            }
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db){
            super.onCreate(db);
        }

    };


}
