package uk.ac.le.co2103.hw4;
import androidx.room.*;
import androidx.lifecycle.*;
import java.util.*;

@Dao
public interface ShoppingListDao {

    @Insert
    void insert(ShoppingList shoppingList);

    @Insert
    void insertProduct(Product product);

    @Query("DELETE FROM shopping_list")
    void deleteAll();

    @Delete
    void deleteAllProducts(List<Product> products);
    @Query("DELETE FROM products")
    void deleteAllProducts();

    @Query("SELECT * FROM shopping_list ORDER BY name ASC")
    LiveData<List<ShoppingList>> getShoppingLists();
    
    @Delete
    void delete(ShoppingList shoppingList);

}
