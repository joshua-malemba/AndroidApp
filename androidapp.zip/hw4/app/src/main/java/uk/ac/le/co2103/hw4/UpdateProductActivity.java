package uk.ac.le.co2103.hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import java.lang.Integer;
public class UpdateProductActivity extends AppCompatActivity {

    private static final String TAG = UpdateProductActivity.class.getSimpleName();
    public static final String EXTRA_REPLY = "uk.edu.le.co2103.hw4.REPLY";
    public static int UPDATE_PRODUCT_ACTIVITY_REQUEST_CODE = 1;

    private EditText editTextItem;
    private EditText editTextQty;
    private Spinner spinner;
    int productQty = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);
        Intent intent = getIntent();

        Bundle extras = intent.getExtras();

        // access clicked product fields
        String prodName = extras.getString(ShoppingListActivity.NAME);
        String prodQty = extras.getString(ShoppingListActivity.QTY);

        editTextItem = findViewById(R.id.updateText);
        editTextItem.setText(prodName);

        editTextQty = findViewById(R.id.updateQuantity);
        editTextQty.setText(prodQty);

        spinner = findViewById(R.id.spinner2);

        /// access index of spinner unit from a given array, and then pass that index as an int through to UpdateProductActivity

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.labels_unit, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        Button save = findViewById(R.id.buttonSave);
        Button incButton = findViewById(R.id.incButton);

        incButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                productQty = productQty + 1;
                editTextQty.setText("" + productQty);
            }
        });

        Button decButton = findViewById(R.id.decButton);

        decButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                productQty = productQty - 1;
                editTextQty.setText("" + productQty);
            }
        });

        save.setOnClickListener(view -> {
            Intent replyIntent = new Intent();
            if (TextUtils.isEmpty(editTextItem.getText())) {
                Log.i(TAG, "Empty text field could be controlled in UI(Save button is disabled)");
                setResult(RESULT_CANCELED, replyIntent);
            }

            else {
                Log.i(TAG, "Saving details....");
                String item = editTextItem.getText().toString();
                replyIntent.putExtra(EXTRA_REPLY, item);
                setResult(RESULT_OK, replyIntent);
            }
            finish();
        });

    }

}