package uk.ac.le.co2103.hw4;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ShoppingRepository {
    private ShoppingListDao shoppingListDao;
    private LiveData<List<ShoppingList>> allShoppingLists;

    ShoppingRepository(Application application){
        ShoppingCartDB db = ShoppingCartDB.getDatabase(application);
        shoppingListDao = db.shoppingListDao();
        allShoppingLists = shoppingListDao.getShoppingLists();
    }

    public LiveData<List<ShoppingList>> getAllShoppingLists() {
        return allShoppingLists;
    }

    void insert(ShoppingList shoppingList){
        ShoppingCartDB.databaseWriteExecutor.execute(() -> {
            shoppingListDao.insert(shoppingList);
        });
    }

    void delete(ShoppingList shoppingList) {
        ShoppingCartDB.databaseWriteExecutor.execute(() -> {
            shoppingListDao.delete(shoppingList);
        });
    }
    
    void deleteProducts(ShoppingList shoppingList) {
        ShoppingCartDB.databaseWriteExecutor.execute(() -> {
            shoppingListDao.deleteAllProducts();
        });
    }


}
