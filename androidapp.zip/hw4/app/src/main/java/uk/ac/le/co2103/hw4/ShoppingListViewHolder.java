package uk.ac.le.co2103.hw4;

import android.Manifest;
import android.Manifest.permission;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import uk.ac.le.co2103.hw4.ShoppingListAdapter;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;


public class ShoppingListViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener{
    private static ShoppingListAdapter.OnItemListener mOnItemListener;
    private static ShoppingListAdapter.OnLongClickItemListener longClickItemListener;
    private ImageView imageView;


    private TextView shoppingListTextView;

    private Button addImage_button;
    private static String TAG = ShoppingListViewHolder.class.getSimpleName();
    private ArrayList<Product> products;

    public ShoppingListViewHolder(@NonNull View shoppingListView, ShoppingListAdapter.OnItemListener mOnItemListener, ShoppingListAdapter.OnLongClickItemListener longClickItemListener) {
        super(shoppingListView);
        shoppingListTextView = shoppingListView.findViewById(R.id.textView);
        imageView = shoppingListView.findViewById(R.id.image);

        this.mOnItemListener = mOnItemListener;
        this.longClickItemListener = longClickItemListener;

        shoppingListView.setOnClickListener(this);
        shoppingListView.setOnLongClickListener(this);
    }



    public Button getAddImage_button() {
        return addImage_button;
    }


    public void bind(String text) {
        shoppingListTextView.setText(text);
    }

    public static ShoppingListViewHolder create(ViewGroup parent, int i, ShoppingListAdapter.OnItemListener mOnItemListener, ShoppingListAdapter.OnLongClickItemListener longClickItemListener) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item, parent, false);

        return new ShoppingListViewHolder(view, mOnItemListener, longClickItemListener);
    }



    @Override
    public void onClick(View v) {
        Log.d(TAG, "shopping list clicked...");
        mOnItemListener.onItemClick(getAdapterPosition());
    }


    @Override
    public boolean onLongClick(View v) {
        Log.d(TAG, "shopping list long clicked...");
        longClickItemListener.longOnItemClick(getAdapterPosition());
        return true;
    }
}
