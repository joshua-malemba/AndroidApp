package uk.ac.le.co2103.hw4;

import android.app.Application;

import androidx.lifecycle.*;
import java.util.*;
import android.content.ClipData.*;


public class ProductViewModel extends AndroidViewModel {
    private ProductRepository repo;
    private final LiveData<List<Product>> allProducts;

    public ProductViewModel(Application application) {
        super(application);
        repo = new ProductRepository(application);
        allProducts = repo.getAllProducts();

    }

    LiveData<List<Product>> getAllProducts(){
        return allProducts;
    }

    public void insert(Product product){
        repo.insert(product);
    }

    public void deleteProduct(Product product){
        repo.delete(product);
    }
}
